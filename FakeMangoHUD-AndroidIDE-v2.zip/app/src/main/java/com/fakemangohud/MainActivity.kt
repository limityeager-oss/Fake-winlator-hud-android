package com.fakemangohud

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var wm: WindowManager
    private var overlay: View? = null
    private val prefs by lazy { getSharedPreferences("hud", MODE_PRIVATE) }

    private fun value(key: String, default: String) =
        prefs.getString(key, default) ?: default

    private fun save(key: String, v: String) =
        prefs.edit().putString(key, v).apply()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        showEditor()
    }

    private fun showEditor() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 24)
        }

        root.addView(TextView(this).apply {
            text = "FakeMangoHUD"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "Mali 1.1-inspired • AndroidIDE/Termux build"
            textSize = 13f
            setPadding(0, 0, 0, 18)
        })

        val specs = listOf(
            "FPS" to "60",
            "Frame time" to "16.6 ms",
            "CPU" to "38%",
            "GPU usage" to "74%",
            "RAM" to "5.2 / 12 GB",
            "VRAM" to "4.0 GB",
            "TEMP" to "47°C",
            "GPU name" to "NVIDIA GeForce RTX 2060",
            "Driver" to "560.94",
            "Vulkan" to "1.3.280",
            "OpenGL" to "4.6",
            "Wrapper" to "DXVK 2.4",
            "Wine" to "Wine 9.21",
            "DXVK FPS" to "60",
            "Game" to "Resident Evil"
        )

        val edits = mutableListOf<Pair<String, EditText>>()

        for ((label, default) in specs) {
            val key = label.lowercase().replace(" ", "_")
            val edit = EditText(this).apply {
                hint = label
                setText(value(key, default))
                setSingleLine(true)
            }
            root.addView(edit, LinearLayout.LayoutParams(-1, 62))
            edits.add(key to edit)
        }

        root.addView(Button(this).apply {
            text = "SAVE + SHOW HUD"
            setOnClickListener {
                edits.forEach { (key, edit) -> save(key, edit.text.toString()) }

                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                    Toast.makeText(
                        this@MainActivity,
                        "Allow Display over other apps, then return and press SHOW again.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    showHud()
                }
            }
        })

        root.addView(Button(this).apply {
            text = "HIDE HUD"
            setOnClickListener { hideHud() }
        })

        root.addView(TextView(this).apply {
            text = "This is a visual/simulation HUD. Values are manually entered and are not real GPU telemetry."
            setPadding(0, 16, 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun hudText(text: String): TextView =
        TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 9.5f
            typeface = Typeface.create("monospace", Typeface.BOLD)
            setShadowLayer(2f, 0f, 1f, Color.BLACK)
        }

    private fun showHud() {
        hideHud()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(9, 6, 9, 7)
            background = GradientDrawable().apply {
                setColor(Color.argb(165, 0, 0, 0))
                cornerRadius = 3f
            }
        }

        box.addView(hudText("▣  FAKE MANGOHUD"))
        box.addView(hudText("────────────────────", 9f))

        val lines = listOf(
            "FPS       ${value("fps", "60")}   ${value("frame_time", "16.6 ms")}",
            "CPU       ${value("cpu", "38%")}",
            "GPU       ${value("gpu_usage", "74%")}",
            "RAM       ${value("ram", "5.2 / 12 GB")}",
            "VRAM      ${value("vram", "4.0 GB")}",
            "TEMP      ${value("temp", "47°C")}",
            "",
            "GPU       ${value("gpu_name", "NVIDIA GeForce RTX 2060")}",
            "DRIVER    ${value("driver", "560.94")}",
            "VULKAN    ${value("vulkan", "1.3.280")}",
            "OPENGL    ${value("opengl", "4.6")}",
            "WRAPPER   ${value("wrapper", "DXVK 2.4")}",
            "WINE      ${value("wine", "Wine 9.21")}",
            "DXVK FPS  ${value("dxvk_fps", "60")}",
            "",
            value("game", "Resident Evil")
        )

        lines.forEach { box.addView(hudText(it)) }

        val type =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 14
            y = 55
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0

        box.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = lp.x
                    startY = lp.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - downX).toInt()
                    lp.y = startY + (event.rawY - downY).toInt()
                    wm.updateViewLayout(box, lp)
                    true
                }
                else -> true
            }
        }

        wm.addView(box, lp)
        overlay = box
        Toast.makeText(this, "HUD ON • drag to move", Toast.LENGTH_SHORT).show()
    }

    private fun hideHud() {
        overlay?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        overlay = null
    }

    override fun onDestroy() {
        hideHud()
        super.onDestroy()
    }
}

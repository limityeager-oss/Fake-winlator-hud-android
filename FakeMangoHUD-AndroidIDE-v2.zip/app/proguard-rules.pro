# Keep rules intentionally empty for this small app.

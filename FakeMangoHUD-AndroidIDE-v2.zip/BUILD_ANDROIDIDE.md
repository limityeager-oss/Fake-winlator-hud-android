# Build on Android

## AndroidIDE
1. Install AndroidIDE.
2. Extract this ZIP into a folder accessible by AndroidIDE.
3. Open/import the project folder.
4. Let Gradle sync.
5. If prompted, install/use JDK 17 and Android SDK 35.
6. Run Build > Assemble Debug.
7. Install the generated `app-debug.apk`.

## Termux
A normal Termux installation does not include the Android SDK/Gradle toolchain automatically.
For a reliable phone-only build, AndroidIDE is recommended. If using Termux, you must separately provide Android SDK 35, build-tools, platform-tools and a compatible JDK/Gradle setup.

## APK output
`app/build/outputs/apk/debug/app-debug.apk`

## Important
The overlay requires the Android permission "Display over other apps".
The HUD values are manually simulated and do not spoof the actual GPU driver.
